const base = '/masteriyo/v1/';
export const urls = {
	courseAnnouncement: base + 'course-announcement',
};
