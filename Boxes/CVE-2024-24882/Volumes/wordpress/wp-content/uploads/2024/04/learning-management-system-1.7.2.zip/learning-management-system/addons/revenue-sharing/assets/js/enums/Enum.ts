export enum WithdrawStatus {
	Approved = 'approved',
	Pending = 'pending',
	Rejected = 'rejected',
}
