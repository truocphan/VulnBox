<?php
/**
 * Masteriyo oxygen integration service providers.
 *
 * @since 1.6.16
 */

use Masteriyo\Addons\OxygenIntegration\Providers\OxygenIntegrationServiceProvider;

return array_unique(
	array(
		OxygenIntegrationServiceProvider::class,
	)
);
