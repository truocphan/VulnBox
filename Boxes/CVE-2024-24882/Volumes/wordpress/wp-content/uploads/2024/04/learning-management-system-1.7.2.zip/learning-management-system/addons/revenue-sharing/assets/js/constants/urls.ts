const base = '/masteriyo/v1/';
export const urls = {
	withdraws: base + 'withdraws',
};
