declare var wp: any;
declare var jQuery: any;
declare var _MASTERIYO_BLOCKS_DATA_: {
	categories: {
		count: number;
		description: string;
		featured_image: number;
		id: number;
		name: string;
		slug: string;
		taxonomy: 'course_cat';
		term_taxonomy_id: number;
	}[];
	isWidgetsEditor: 'yes' | 'no';
	isCustomizer: 'yes' | 'no';
};
