<?php
/**
 * Setup revenue sharing addon.
 *
 * @since 1.6.14
 */

wp_roles()->add_cap( 'administrator', 'manage_withdraws' );
