declare var jQuery;

declare var _MASTERIYO_STYLE_TEMPLATES_: {
	[widgetName: string]: any[];
};

declare var _MASTERIYO_SPECIAL_SETTINGS_: {
	[settingName: string]: string;
};
