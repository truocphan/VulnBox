<?php
/**
 * Masteriyo Divi integration service providers.
 *
 * @since 1.6.13
 */

use Masteriyo\Addons\DiviIntegration\Providers\DiviIntegrationServiceProvider;

return array_unique(
	array(
		DiviIntegrationServiceProvider::class,
	)
);
