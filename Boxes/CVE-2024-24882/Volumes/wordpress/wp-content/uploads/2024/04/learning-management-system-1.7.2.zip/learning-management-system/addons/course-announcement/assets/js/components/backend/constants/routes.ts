export const routes = {
	courseAnnouncements: {
		list: '/course-announcements',
		edit: '/course-announcements/:id',
	},
};
